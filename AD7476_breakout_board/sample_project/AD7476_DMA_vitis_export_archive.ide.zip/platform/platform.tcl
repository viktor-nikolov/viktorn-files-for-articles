# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct C:\MicroZed_projects\AD7476_ADC\AD7476_DMA_lwip_test_swClass\platform\platform.tcl
# 
# OR launch xsct and run below command.
# source C:\MicroZed_projects\AD7476_ADC\AD7476_DMA_lwip_test_swClass\platform\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {platform}\
-hw {C:\MicroZed_projects\AD7476_ADC\AD7476_DMA_test_hw\system_wrapper.xsa}\
-proc {ps7_cortexa9_0} -os {freertos10_xilinx} -out {C:/MicroZed_projects/AD7476_ADC/AD7476_DMA_lwip_test_swClass}

platform write
platform generate -domains 
platform active {platform}
bsp reload
bsp setlib -name lwip220 -ver 1.0
bsp config api_mode "SOCKET_API"
bsp config lwip_dhcp "true"
bsp config phy_link_speed "CONFIG_LINKSPEED1000"
bsp write
bsp reload
catch {bsp regenerate}
platform generate
platform active {platform}
platform generate -domains 
platform active {platform}
platform config -updatehw {c:/MicroZed_projects/AD7476_ADC/AD7476_DMA_test_hw/system_wrapper.xsa}
platform generate -domains 
