/*
This is a demo program for reading data from one or two ADCs on Digilent Pmod AD1
(or a similar circuit) and sending them in a binary form to a remote socks server for processing and plotting.

BSD 2-Clause License:

Copyright (c) 2025 Viktor Nikolov

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include "FreeRTOS.h"
#include "task.h"
#include "xgpiops.h"
#include "xgpio.h"
#include "xaxidma.h"
#include "xparameters.h"
#include "lwip/sys.h"

#include <unordered_map>
#include <string_view>
#include <iostream>
#include <iomanip>
using std::cout;
using std::cerr;
using std::endl;

#include "button_debounce.h"
#include "FileViaSocket.h"

/* Number of samples transferred in one DMA transfer. Max. value is 33,554,431 */
#define SAMPLE_COUNT 20000

#if SAMPLE_COUNT > 0x01FFFFFF
	#error "SAMPLE_COUNT is higher than possible max. of 33,554,431 (>0x01FFFFFF)"
#endif

/* The IP address and port of the server script AD7476_visualiser.py receiving the data.
 * The address must be provided in numerical form in a string, e.g., "192.168.44.10".*/
const std::string    SERVER_ADDR( "###SERVER_ADDR is not set###" );
//const std::string    SERVER_ADDR( "192.168.44.10" );
const unsigned short SERVER_PORT{ 65432 }; // The server script AD7476_visualiser.py uses the port 65432 by default.

// Size of the stack (as number of 32bit words) for FreeRTOS threads we create
#define STANDARD_THREAD_STACKSIZE 1024

/********* AXI GPIO configuration *********/

// This enum lists AXI GPIO instances we have in our HW design
enum class eGPIO { Start, Count, SecondADCEnabled };

// This helper structure stores configuration parameters for the AXI GPIO instances.
struct sGPIO {
#ifdef SDT // Is System Device Tree used? (I.e., are we using Vitis Unified?)
	sGPIO( UINTPTR ba, std::string_view name ) : BaseAddress(ba), Name(name) {}
    UINTPTR BaseAddress;
#else
    sGPIO( u16 did, std::string_view name ) : DeviceID(did), Name(name) {}
    u16 DeviceID;
#endif
	std::string_view Name; // Used only for error reporting purposes
	XGpio GPIOInstance;
};

/* Define configuration parameters of the AXI GPIO instances */
/* We are using std::unordered_map because the hash function of an enum
   is a simple conversion to the underlying integer value. In other words,
   we are accessing an array indexed by enum. It's fast access. */
#ifdef SDT // Is System Device Tree used? (I.e., are we using Vitis Unified?)
std::unordered_map<eGPIO, sGPIO> GPIO = {
	{ eGPIO::Start,            { XPAR_AXI_GPIO_0_BASEADDR, "start"} },
	{ eGPIO::Count,            { XPAR_AXI_GPIO_1_BASEADDR, "count"} },
	{ eGPIO::SecondADCEnabled, { XPAR_AXI_GPIO_2_BASEADDR, "second_adc_enabled"} }
};
#else
std::unordered_map<eGPIO, sGPIO> GPIO = {
	{ eGPIO::Start,            { XPAR_AXI_GPIO_0_DEVICE_ID, "start"} },
	{ eGPIO::Count,            { XPAR_AXI_GPIO_1_DEVICE_ID, "count"} },
	{ eGPIO::SecondADCEnabled, { XPAR_AXI_GPIO_2_DEVICE_ID, "second_adc_enabled"} }
};
#endif

extern sys_thread_t network_init_thread_handle; // Defined in network_thread.cpp
extern void network_init_thread(void *p);       // Defined in network_thread.cpp

/* We need the target buffer of the DMA transfer to be aligned on an address divisible by 4.
 * We are also making it 16 bytes larger than needed, because we need to invalidate Data Cache
 * in a slightly bigger memory range. Otherwise we risk cache issues caused by end of the buffer
 * not aligned with cache line. */
static u16 DataBuffer[ SAMPLE_COUNT + 8 ] __attribute__((aligned(4)));

static XGpioPs GpioInstance;   // The PS GPIO instance
static XAxiDma AxiDmaInstance; // The AXI DMA instance

static bool IsSecondADCEnabled = false; // Are we reading data from the second ADC on the Pmod AD1

// Function setting output on one of the AXI GPIO instances
__attribute__((always_inline)) static inline
void GpioWrite( eGPIO gpio, u32 data )
{
	XGpio_WriteReg( GPIO.at(gpio).GPIOInstance.BaseAddress, 0 /*RegOffset*/, data);
}

// Initialize the GPIO subsystem
static int GPIOInitialize()
{
	/*** Initialize the PS GPIO  ****/

    XGpioPs_Config *GpioConfig;
	XStatus Status;

#ifdef SDT // Is System Device Tree used? (I.e., are we using Vitis Unified?)
	GpioConfig = XGpioPs_LookupConfig(XPAR_XGPIOPS_0_BASEADDR);
#else
	GpioConfig = XGpioPs_LookupConfig(XPAR_XGPIOPS_0_DEVICE_ID);
#endif
	if(GpioConfig == NULL) {
		cerr << "XGpioPs_LookupConfig failed! terminating" << endl;
		return XST_FAILURE;
	}

	Status = XGpioPs_CfgInitialize(&GpioInstance, GpioConfig, GpioConfig->BaseAddr);
	if(Status != XST_SUCCESS) {
		cerr << "XGpioPs_CfgInitialize failed! terminating" << endl;
		return XST_FAILURE;
	}

	/* Initialize the PS GPIO pins */

	/* There are 64 EMIO GPIO pins on Zynq-7000. The first 32 pins are in Bank 2 (EMIO pin numbers 54 through 85),
	 * the rest of the pins are in Bank 3.
	 * In the hardware design, we defined the use of the GPIO pins as follows:
	 * EMIO GPIO pin 54 is connected to the board's button BTN0 and pin 55 is connected to BTN1. */
	XGpioPs_SetDirection( &GpioInstance, 2 /*Bank 2*/, 0 );  // Set all Bank 2 pins as inputs (we use only first two of them)
	
	/*** Initialize the AXI GPIO instances ****/

	for( auto& pair : GPIO ) {
		/* Note: We don't need to set direction because it was set as "all output" in the HW design
		         in configuration of the AXI GPIO IPs.*/
#ifdef SDT // Is System Device Tree used? (I.e., are we using Vitis Unified?)
		Status = XGpio_Initialize(&pair.second.GPIOInstance, pair.second.BaseAddress);
#else
		Status = XGpio_Initialize(&pair.second.GPIOInstance, pair.second.DeviceID);
#endif
		if( Status != XST_SUCCESS )
		{
			cerr << "XGpio_Initialize failed for " << pair.second.Name << "! terminating..." << endl;
			return XST_FAILURE;
		}
	}

	/* Initialize the AXI GPIO outputs */
	GpioWrite( eGPIO::Start, 0 );
	GpioWrite( eGPIO::Count, SAMPLE_COUNT );
	GpioWrite( eGPIO::SecondADCEnabled, IsSecondADCEnabled );

	return 0;
} // GPIOInitialize

// Initialize AXI DMA
static int DMAInitialize()
{
	XAxiDma_Config *cfgptr;
	XStatus Status;

#ifdef SDT // Is System Device Tree used? (I.e., are we using Vitis Unified?)
	cfgptr = XAxiDma_LookupConfig(XPAR_AXI_DMA_0_BASEADDR); // The macro comes from xparameters.h
#else
	cfgptr = XAxiDma_LookupConfig(XPAR_AXI_DMA_0_DEVICE_ID); // The macro comes from xparameters.h
#endif
	if(cfgptr == NULL) {
		cerr << "XAxiDma_LookupConfig  failed! terminating" << endl;
		return XST_FAILURE;
	}

	Status = XAxiDma_CfgInitialize(&AxiDmaInstance, cfgptr);
	if(Status != XST_SUCCESS) {
		cerr << "XAxiDma_CfgInitialize failed! terminating" << endl;
		return XST_FAILURE;
	}

	// Disable interrupts
	XAxiDma_IntrDisable(&AxiDmaInstance, XAXIDMA_IRQ_ALL_MASK, XAXIDMA_DEVICE_TO_DMA);
	XAxiDma_IntrDisable(&AxiDmaInstance, XAXIDMA_IRQ_ALL_MASK, XAXIDMA_DMA_TO_DEVICE);

	return 0;
} // DMAInitialize

// Perform a DMA transfer of digitized samples from ADC into RAM
static int ReceiveData()
{
	Xil_DCacheFlushRange( (UINTPTR)DataBuffer, sizeof(DataBuffer) );  // Just in case, flush any data in DataBuffer, held in CPU cache, to RAM

	// Initiate the DMA transfer
	XStatus Status;
	Status = XAxiDma_SimpleTransfer( &AxiDmaInstance, (UINTPTR)DataBuffer, SAMPLE_COUNT * sizeof(u16), XAXIDMA_DEVICE_TO_DMA );
	if(Status != XST_SUCCESS) {
		cerr << "XAxiDma_SimpleTransfer failed! terminating" << endl;
		return XST_FAILURE;
	}

	GpioWrite( eGPIO::Start, 1 ); // Set start signal to initiate generation of the AXI-Stream of data coming from ADC
	GpioWrite( eGPIO::Start, 0 ); // Reset the start signal (it needed to be high for just a single PL clock cycle)

	while( XAxiDma_Busy(&AxiDmaInstance, XAXIDMA_DEVICE_TO_DMA) ) // Wait until DMA transfer is done
		vTaskDelay( pdMS_TO_TICKS( 1 ) ); // Wait 1 ms

	/* Invalidate the CPU cache for the memory region holding the DataBuffer.
	 * The DMA transfer wasn't using the CPU cache, it wrote directly to RAM.
	 * We need the CPU to get data from the RAM, not cache, when processing data in the DataBuffer.*/
	Xil_DCacheInvalidateRange( (UINTPTR)DataBuffer, sizeof(DataBuffer) );

	return 0;
} // ReceiveData

/* FreeRTOS thread of the main controlling logic of the application.
 * The network_init_thread will start AD7476_thread after the network is initialized.
 */
void AD7476_thread(void *)
{
	cout << "***** AD7476 THREAD STARTED *****\n";
	cout << "will connect to the network address " << SERVER_ADDR << ':' << SERVER_PORT << endl;
	cout << "samples per DMA transfer: " << SAMPLE_COUNT << endl;

	// Initialize the subsystems
	if( GPIOInitialize() == XST_FAILURE )
		vTaskDelete(NULL); // We end this thread on an error
	if( DMAInitialize()  == XST_FAILURE )
		vTaskDelete(NULL);

	cout << "\npress BTN0 to start ADC conversion" << endl
	     << "press BTN1 to turn on or off the second ADC" << endl;

    cout << "\nsecond ADC is " << ( IsSecondADCEnabled ? "enabled" : "disabled" ) << endl;

	// The object for debouncing the buttons (i.e., for ensuring that the app gets a filtered signal from the buttons for smooth control)
	Debouncer btns( 0 ); // Passing 0 to the constructor because our buttons are pull-down buttons

	while(1) {
		/* Give status of the buttons to the debouncer.
		 * First two EMIO pins are connected to BTN0 and BTN1. They are represented as the two
		 * least significant bits. */
		btns.ButtonProcess( XGpioPs_Read( &GpioInstance, 2 /*Bank 2*/ ) );

		if( btns.ButtonPressed(BUTTON_PIN_0) ) { // If button BTN0 was pressed
			if( ReceiveData() == XST_FAILURE )   // Perform a DMA transfer of digitized samples from ADC into RAM
				vTaskDelete(NULL); // We end this thread on error

			// Print the first 8 data samples to the console.
			cout << "\n***** ADC DATA[0..7] *****\n";
			cout << std::hex << std::uppercase;
			for( int i = 0; i < 8 && i < SAMPLE_COUNT; i++ )
				cout << std::setw(4) << DataBuffer[i] << endl;

			// Transfer data over the network
			try {
				DataViaSocket sckt( SERVER_ADDR, SERVER_PORT ); // Declare the object and open the network connection

				cout << "sending data..." << std::flush;
				sckt.write( reinterpret_cast<const char *>(DataBuffer), SAMPLE_COUNT * sizeof(DataBuffer[0]) );

				cout << "   sent" << endl;
			} // When this scope ends, object sckt is destroyed, its destructor closes the connection.
			catch( const std::exception& e ) {
				cerr << "Error on opening the socket:\n" << e.what() << endl;
			}
		}

		if( btns.ButtonPressed(BUTTON_PIN_1) ) { // If button BTN1 was pressed
			// Activate or deactivate data read from the second ADC
            IsSecondADCEnabled = !IsSecondADCEnabled;
           	GpioWrite( eGPIO::SecondADCEnabled, IsSecondADCEnabled );
            cout << "second ADC is " << ( IsSecondADCEnabled ? "enabled" : "disabled" ) << endl;
		}

		vTaskDelay( pdMS_TO_TICKS( 10 ) ); // Wait 10 ms
	} // while(1)
} // XADC_thread

int main()
{
	cout << "\n*************** PROGRAM STARTED ***************" << endl;

	/* Starting the thread, which initializes the network.
	 * It will start the AD7476_thread when the network is ready. */
	network_init_thread_handle = sys_thread_new("network_init_thread", network_init_thread, 0,
	                                            STANDARD_THREAD_STACKSIZE,
	                                            DEFAULT_THREAD_PRIO);
	vTaskStartScheduler();

	return 0;
} // main
