# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: C:\MicroZed_projects\AD7476_ADC\AD7476_DMA_lwip_test_swClass\AD7476_test_system\_ide\scripts\debugger_ad7476_test-default.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source C:\MicroZed_projects\AD7476_ADC\AD7476_DMA_lwip_test_swClass\AD7476_test_system\_ide\scripts\debugger_ad7476_test-default.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -filter {jtag_cable_name =~ "Digilent Zybo Z7 210351B7BB6BA" && level==0 && jtag_device_ctx=="jsn-Zybo Z7-210351B7BB6BA-23727093-0"}
fpga -file C:/MicroZed_projects/AD7476_ADC/AD7476_DMA_lwip_test_swClass/AD7476_test/_ide/bitstream/system_wrapper.bit
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw C:/MicroZed_projects/AD7476_ADC/AD7476_DMA_lwip_test_swClass/platform/export/platform/hw/system_wrapper.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source C:/MicroZed_projects/AD7476_ADC/AD7476_DMA_lwip_test_swClass/AD7476_test/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow C:/MicroZed_projects/AD7476_ADC/AD7476_DMA_lwip_test_swClass/AD7476_test/Debug/AD7476_test.elf
configparams force-mem-access 0
targets -set -nocase -filter {name =~ "*A9*#0"}
con
